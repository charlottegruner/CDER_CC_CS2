import greenfoot.*;

public class Kriegercannon extends Actor
{
    /**
     * Act - do whatever the Kriegercannon wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        move(10);
        splatter();
    }    
    public void splatter()
    {
        if (isTouching(Bird.class))
        {
            Krieger krieger = new Krieger();
            getWorld().addObject(krieger, getX(), getY());
            removeTouching(Bird.class);
        }
        if (isAtEdge())
        {
            getWorld().removeObject(this);
        }
    }

}
